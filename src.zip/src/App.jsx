import Navbar from "./components/navbar";
import "./App.css";
import "./index.css";
import LatestUpdates from "./components/latest-updates";

function App() {
  return (
    <>
    
      <div className="app-container h-screen w-screen flex justify-center items-center relative">
        <video
          className="w-full h-full object-cover scale-125 absolute"
          autoPlay
          loop
          muted
        >
          <source src="/what_if.mp4" type="video/mp4" />
        </video>
        <div style={{ fontFamily: 'Akira, sans-serif', fontSize: '' }}>
        <h1 className="absolute top-18 left-15 p-5 font-bold text-black text-5xl">
        WHAT'S NEW
        </h1>
        </div>
        <LatestUpdates />
        <Navbar />
      
      </div>
    </>
  );
}

export default App;
//ussereeffect real time fecthing krta hai
//userstate data store krta hai jo fetch kya h