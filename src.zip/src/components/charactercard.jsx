import React, { useEffect, useState } from "react";
import { fetchCharacterData } from "../components/movie_api";

export default function CharacterCard({
  character,
  isHovered,
  onHover,
  onLeave,
}) {
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (isHovered && !info) {
      setLoading(true); //loading
      fetchCharacterData(character.name) //searching name
        .then((data) => {
          setInfo(data); //data milega
        })
        .catch(() => {
          setInfo({ bio: "Info not found", movies: [] });
        })
        .finally(() => setLoading(false));
    }
  }, [isHovered, character.name, info]); //call
  return (
    //hover effects on images
    <div
      className="group absolute transition-transform duration-300 transform hover: cursor-pointer top-10 h-80 left-0 m-5 "
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
    >
      <img
        src={character.image}
        alt={character.name}
        style={
          character.name === "IronMan"
            ? {
                left: "540px",
                position: "relative",
                width: "32rem",
                height: "850px",
                top: "-120px",
              }
            : character.name === "SpiderMan"
            ? {
                left: "1000px",
                position: "relative",
                width: "15rem",
                height: "400px",
                top: "-80px",
              }
            : character.name === "BlackPanthar"
            ? {
                left: "1190px",
                position: "relative",
                width: "23rem",
                height: "650px",
                top: "50px",
              }
            : character.name === "Hawkeye"
            ? {
                left: "800px",
                position: "relative",
                width: "20rem",
                height: "500px",
                top: "50px",
              }
            : character.name === "BlackWidow"
            ? {
                left: "860px",
                position: "relative",
                width: "27rem",
                height: "470px",
                top: "185px",
              }
            :
            character.name === "Hulk"
            ? {
                position: "relative",
                width: "18rem",
                height: "400px",
                top: "250px",
              }
            :
            character.name === "CaptainAmerica"
            ? {
                left: "220px",
                position: "relative",
                width: "18rem",
                height: "500px",
                top: "-50px",
              }
            : character.name === "Thor"
            ? {
                left: "380px",
                position: "relative",
                width: "18rem",
                height: "500px",
                top: "150px",
              }
            :   {}
        }
      />
      {isHovered && (
        <div className="absolute rounded inset-0 backdrop-blur bg-opacity-70 flex flex-col justify-center items-center text-white p-4">
          <h2 className="text-2xl font-bold mb-2">{character.name}</h2>

          {loading && <p>Loading info...</p>}

          {info && !loading && (
            <>
              <p className="italic mb-2">{info.bio}</p>
              <div className="movies-grid">
                {info.movies.map((m) =>
                  m.posterUrl ? (
                    <img
                      key={m.title}
                      src={m.posterUrl}
                      alt={m.title + " poster"}
                      className="movie-poster"
                    />
                  ) : (
                    <span key={m.title}>{m.title}</span>
                  )
                )}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
