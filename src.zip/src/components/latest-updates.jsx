import axios from "axios";
import { useEffect, useState } from "react";//using hooks

// Fetching the news using axios md5

const LatestUpdates = () => {
  const [article, setArticle] = useState([]);
  const [loading, setLoading] = useState(true);
  const [show, setShow] = useState(false); // Add this line

  useEffect(() => {
    const timer = setTimeout(() => setShow(true), 2000);
    return () => clearTimeout(timer);//mene api kaha dala tha?
  }, []);
  //here we are fecthing the data in real time in this file only
  useEffect(() => {
    const fetcharticle = async () => {
      try {
        const res = await axios.get("https://newsapi.org/v2/everything", {
          params: {
            q: "marvel cinematic universe OR avengers",
            language: "en",
            sortBy: "publishedAt",
            apiKey: "2b2ef38f8a2644be865ce92abd45f9ff",
          },
        });

        setArticle(res.data.articles);
      } catch (error) {
        console.error("Failed to fetch Marvel news:", error);
      } finally {
        setLoading(false);
      }
    };
    fetcharticle();
  }, []);

  //Displaying the news
  if (loading) {
    return <p className="text-center text-lg mt-10">📰 Loading Marvel news...</p>;
  }
  return (
    <div className={`text-xl top-40 absolute left-10 transition-transform duration-900 ${
        show ? "translate-x-0 opacity-100" : "-translate-x-40 opacity-0"
      }`}>
      <div className="grid gap-5 h-150 w-380 overflow-auto scrollbar-hide">
        {article.slice(0, 6).map((article, index) => (
          <div
            key={index}
            className={`rounded-xl p-5 transition-all backdrop-brightness-200 duration-300 `}
          >
            <h2 className="text-xl font-semibold ">{article.title}</h2>
            <p className="text-sm text-gray-500 mb-2 ">
              {new Date(article.publishedAt).toLocaleDateString()}
            </p>
            <p className="mb-3">{article.description}</p>
            <a
              href={article.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-800 hover:underline"
            >
              →
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LatestUpdates;
// import React from 'react'






















































//me everywhere lol:)