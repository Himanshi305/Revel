import React from 'react'

const sec = () => {
  return (
    <div>
      Character
    </div>
  )
}

export default sec
