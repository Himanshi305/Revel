import React from "react";
import { Link } from "react-router-dom";
const Navbar = () => {
  return (
    <div style={{ fontFamily: "Spidy, sans-serif", fontSize: "35px" }}>
      <nav className="absolute top-0 left-0 w-full gap-15 flex items-center p-3.5 bg-transparent">
        <div className="home">
          <Link to="/" className="text-red-600 hover:text-5xl transition-all">
            Home
          </Link>
        </div>
        <div className="items gap-5 flex ">
          <Link
            to="/character"
            className="text-black hover:text-5xl transition-all"
          >
            Character
          </Link>
          <Link
            to="/phases"
            className="text-red-600 hover:text-5xl transition-all "
          >
            Phases
          </Link>
          <Link
            to="/timeline"
            className="text-black hover:text-5xl transition-all"
          >
            Timeline
          </Link>
        </div>
        <div className="intro ml-auto px-15">
          <Link
            to="/intro"
            className="text-blue-800 hover:text-5xl transition-all"
          >
            Introduction
          </Link>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
