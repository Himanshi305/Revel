import React, { useState } from "react";
import Navbar from "../components/navbar";
import CharacterCard from "../components/charactercard";
import { characters } from "../data/char_data";

function Character() {
  const [hoveredChar, setHoveredChar] = useState(null);
  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 h-screen">
        {characters.map((char) => (
          <CharacterCard
            key={char.name}
            character={char}
            isHovered={hoveredChar === char.name}
            onHover={() => setHoveredChar(char.name)}
            onLeave={() => setHoveredChar(null)}
          />
        ))}
        <div
          style={{
            height: "100vh",
            width: "100vw",
            backgroundImage: "url(/character_background.jpg)",
            backgroundSize: "cover",
            backgroundPosition: "center",
            backgroundRepeat: "no-repeat",
            overflow: "hidden",
          }}
        >
          {/* Your content */}
        </div>
        <Navbar />
      </div>
    </div>
  );
}

export default Character;
