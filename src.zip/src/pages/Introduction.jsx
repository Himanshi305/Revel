import React from "react";
import Navbar from "../components/navbar"; //this
const Introduction = () => {
  return (
    <>
      <div className="intro h-screen w-screen relative">
        <video
          className="w-full h-full object-cover scale-125 absolute"
          autoPlay
          loop
          muted
        >
          <source src="/HOPE.mp4" type="video/mp4" />
        </video>
        <div className="intropfp absolute top-30 left-20">
          <img src="/pfp.jpg" alt="" className="rounded-full w-50 h-50" />
        </div>
        <span></span>
      </div>
      <Navbar />
    </>
  );
};

export default Introduction;
