import React from "react";
import Navbar from "../components/navbar";
function Timeline() {
  return (
    <div>
      <Navbar />
    </div>
  );
}//
export default Timeline;