import React from "react";
import Navbar from "../components/navbar";
function Phases() {
  return (
    <div>
      <Navbar />
    </div>
  );
}
export default Phases;