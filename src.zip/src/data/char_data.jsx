export const characters = [ 
  { name: 'Hawkeye', image: '/hawkeye.png' }, 
  { name: 'Hulk' , image: '/Hulk2.png'},
  { name: 'BlackPanthar', image: '/Black_panther.png' },
  { name: 'SpiderMan' , image: '/spider-man.png'},
  { name: 'BlackWidow' , image: '/widow.png'},
  { name: 'CaptainAmerica', image: '/cap.png' },
  { name: 'Thor', image: '/thor.png' },
  { name: 'IronMan', image: '/iron2.png' },
];